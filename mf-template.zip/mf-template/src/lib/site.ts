import data from "../../content/site.json";

export interface Site {
  meta: { slug: string; lang?: string };
  theme?: { accent?: string };
  business: {
    name: string; tagline?: string; branche?: string;
    phone: string; email?: string; address?: string; hours?: string;
    areas?: string[];
  };
  hero: { headline: string; subline?: string; cta?: { label: string; href: string } };
  services?: { title: string; desc: string }[];
  usps?: string[];
  about?: string;
  testimonials?: { text: string; author: string }[];
  contact?: { headline?: string; note?: string };
  seo: { title: string; description: string; ogImage?: string };
}

const site = data as Site;
export const accent = site.theme?.accent ?? "#0E7490";
export const telHref = "tel:" + site.business.phone.replace(/[^+\d]/g, "");
export default site;
