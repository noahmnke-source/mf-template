# mf-template

Astro-Template für die Manke-&-Frost-Lead-Pipeline. Es rendert die Datei
`content/site.json` zu einer fertigen, mobiloptimierten Local-Business-Seite.

## So nutzt der Worker es
`generate-and-deploy.sh` klont dieses Repo, legt die generierte `content/site.json`
hinein, baut (`npm ci && npm run build` → `dist/`) und deployt `dist` auf Netlify.

## Lokal testen
```bash
npm install
npm run dev      # http://localhost:4321
npm run build    # erzeugt ./dist
```
Zum Ausprobieren einfach `content/site.json` bearbeiten.

## Felder
Siehe `SITE-JSON-KONVENTION.md` im Pipeline-Bundle. Neu/optional:
`theme.accent` = Akzent-Hexfarbe pro Kunde (Default `#0E7490`, dezentes Petrol).
Fehlende optionale Blöcke (z. B. `testimonials`) werden automatisch ausgeblendet.

## Anpassen
- Globale Optik: `src/styles/global.css` (Farben, Radius, Typo)
- Schriftarten: `src/layouts/Base.astro` (Google Fonts)
- Aufbau/Reihenfolge der Sektionen: `src/pages/index.astro`
