import { defineConfig } from "astro/config";
export default defineConfig({
  // statische Seite -> Output landet in ./dist
});
